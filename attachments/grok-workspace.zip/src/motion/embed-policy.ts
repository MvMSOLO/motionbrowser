const RESTRICTED_SUFFIXES = [
  "instagram.com",
  "youtube.com",
  "youtu.be",
  "facebook.com",
  "fb.com",
  "tiktok.com",
  "twitter.com",
  "x.com",
  "accounts.google.com",
];

export function knownEmbedRestriction(hostname: string): string | null {
  const host = hostname.toLowerCase().replace(/\.$/, "");
  for (const suffix of RESTRICTED_SUFFIXES) {
    if (host === suffix || host.endsWith(`.${suffix}`)) {
      return `${host} usually refuses to be embedded.`;
    }
  }
  return null;
}

export function interpretFrameHeaders(xFrameOptions: string | null, csp: string | null): { embeddable: boolean; reason: string } {
  if (xFrameOptions) {
    const value = xFrameOptions.toLowerCase();
    if (value.includes("deny") || value.includes("sameorigin") || value.includes("allow-from")) {
      return { embeddable: false, reason: "This site sent X-Frame-Options and will not render inside the frame." };
    }
  }
  if (csp) {
    const match = csp.match(/frame-ancestors\s+([^;]+)/i);
    if (match) {
      const tokens = match[1].toLowerCase().split(/\s+/).filter(Boolean);
      const open = tokens.includes("*");
      const closed = tokens.includes("'none'") || tokens.includes("'self'") || !open;
      if (closed) {
        return { embeddable: false, reason: "This site's content security policy blocks embedded frames." };
      }
    }
  }
  return { embeddable: true, reason: "No frame-blocking header was found. The site may still choose not to run here." };
}
