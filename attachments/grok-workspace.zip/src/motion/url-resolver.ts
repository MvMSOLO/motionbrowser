export type ResolveResult =
  | { kind: "internal"; id: "lab"; label: string }
  | { kind: "navigate"; url: string; display: string }
  | { kind: "search"; query: string; provider: "duckduckgo" }
  | { kind: "error"; message: string };

const ALIASES: Record<string, string> = {
  instagram: "https://www.instagram.com/",
  insta: "https://www.instagram.com/",
  ig: "https://www.instagram.com/",
  youtube: "https://www.youtube.com/",
  yt: "https://www.youtube.com/",
  wikipedia: "https://en.wikipedia.org/",
  wiki: "https://en.wikipedia.org/",
  example: "https://example.com/",
};

const LAB_ALIASES = new Set(["lab", "motion lab", "gesture lab", "motionlab"]);

const BLOCKED_SCHEMES = new Set([
  "javascript",
  "file",
  "content",
  "data",
  "blob",
  "intent",
  "about",
  "chrome",
  "chrome-extension",
  "view-source",
]);

export function isBlockedHost(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/\.$/, "").replace(/^\[|\]$/g, "");
  if (!host) return true;
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) return true;
  if (host === "metadata.google.internal" || host === "0.0.0.0") return true;
  if (host === "::1" || host.startsWith("fc") || host.startsWith("fd") || host.startsWith("fe80")) return true;
  const ipv4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (!ipv4) return false;
  const a = Number(ipv4[1]);
  const b = Number(ipv4[2]);
  if ([a, b, Number(ipv4[3]), Number(ipv4[4])].some((n) => n > 255)) return true;
  if (a === 10 || a === 127 || a === 0) return true;
  if (a === 169 && b === 254) return true;
  if (a === 192 && b === 168) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  return false;
}

function displayHost(url: URL): string {
  return url.hostname.replace(/^www\./, "");
}

function acceptHttps(url: URL): ResolveResult {
  if (url.username || url.password) {
    return { kind: "error", message: "Addresses with embedded usernames or passwords are not opened." };
  }
  if (isBlockedHost(url.hostname)) {
    return { kind: "error", message: "Local and private network addresses are not opened in the embedded view." };
  }
  url.hash = "";
  return { kind: "navigate", url: url.toString(), display: displayHost(url) };
}

export function resolveAddress(input: string): ResolveResult {
  const trimmed = input.trim();
  if (!trimmed) return { kind: "error", message: "Enter a site name, domain, or search." };
  if (trimmed.length > 500) return { kind: "error", message: "That address is too long." };

  const normalized = trimmed.replace(/\s+/g, " ");
  const key = normalized.toLowerCase();
  if (LAB_ALIASES.has(key)) return { kind: "internal", id: "lab", label: "Motion lab" };
  if (ALIASES[key]) {
    return acceptHttps(new URL(ALIASES[key]));
  }

  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(trimmed);
  if (scheme) {
    const name = scheme[1].toLowerCase();
    if (BLOCKED_SCHEMES.has(name) || (name !== "http" && name !== "https")) {
      return { kind: "error", message: "That address uses a scheme Motion Browser will not open." };
    }
    let candidate = trimmed;
    if (name === "http") candidate = `https://${trimmed.slice(scheme[0].length)}`;
    try {
      const url = new URL(candidate);
      if (url.protocol !== "https:") {
        return { kind: "error", message: "Only HTTPS sites are opened." };
      }
      return acceptHttps(url);
    } catch {
      return { kind: "error", message: "That address could not be read. Check it and try again." };
    }
  }

  if (/\s/.test(normalized) || !normalized.includes(".")) {
    return { kind: "search", query: normalized.slice(0, 180), provider: "duckduckgo" };
  }

  const domain = /^([a-z0-9.-]+\.[a-z]{2,})([/?#].*)?$/i.exec(normalized);
  if (!domain) return { kind: "search", query: normalized.slice(0, 180), provider: "duckduckgo" };
  try {
    return acceptHttps(new URL(`https://${normalized}`));
  } catch {
    return { kind: "error", message: "That address could not be read. Check it and try again." };
  }
}
