import { createServerFn } from "@tanstack/react-start";
import { interpretFrameHeaders, knownEmbedRestriction } from "./embed-policy";
import { isBlockedHost } from "./url-resolver";

export type ProbeResult = {
  embeddable: boolean;
  uncertain: boolean;
  reason: string;
  status: number;
};

export const probeEmbed = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!input || typeof input !== "object" || !("url" in input)) throw new Error("Missing address");
    const parsed = new URL(String((input as { url: unknown }).url));
    if (parsed.protocol !== "https:" || isBlockedHost(parsed.hostname)) throw new Error("Address refused");
    return { url: parsed.toString(), hostname: parsed.hostname };
  })
  .handler(async ({ data }): Promise<ProbeResult> => {
    const known = knownEmbedRestriction(data.hostname);
    try {
      const dns = await import("node:dns/promises");
      const lookedUp = await dns.lookup(data.hostname, { all: true });
      if (lookedUp.some((row) => isBlockedHost(row.address))) {
        return { embeddable: false, uncertain: false, reason: "That host resolved to a private address.", status: 0 };
      }
      const response = await fetch(data.url, {
        method: "GET",
        redirect: "follow",
        signal: AbortSignal.timeout(8000),
        headers: { "user-agent": "MotionBrowserEmbedProbe/0.1" },
      });
      const verdict = interpretFrameHeaders(response.headers.get("x-frame-options"), response.headers.get("content-security-policy"));
      if (!verdict.embeddable) return { embeddable: false, uncertain: false, reason: verdict.reason, status: response.status };
      if (known) {
        return {
          embeddable: false,
          uncertain: true,
          reason: `${known} The header check did not show a block, but this shell still will not pretend the site is supported.`,
          status: response.status,
        };
      }
      return { embeddable: true, uncertain: false, reason: verdict.reason, status: response.status };
    } catch {
      if (known) return { embeddable: false, uncertain: false, reason: known, status: 0 };
      return {
        embeddable: false,
        uncertain: true,
        reason: "Motion Browser could not confirm that this site allows an embedded frame.",
        status: 0,
      };
    }
  });
